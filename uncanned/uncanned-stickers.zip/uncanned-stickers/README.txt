UNCANNED — STICKER ASSET BUNDLE
================================
13 brand stickers, extracted from the Uncanned brand sticker sheet
(Confetti, 2025). Use as scattered "stickies" around the website
landing page — placed in the margins/corners, leaving the center clear
for headlines and CTAs.

WHAT'S INSIDE
-------------
/die-cut/            PNG, transparent background. Each sticker has a
                     warm off-white die-cut border (#FFFDF5) + clean
                     edge so it reads as a real vinyl sticker. PRIMARY SET.

/die-cut-2x/         Same set, upscaled 2x (Lanczos) for retina / larger
                     placements. Note: interpolated, not extra detail.

/plain-transparent/  PNG, transparent background, NO border. Use these
                     to apply your own border / shadow / treatment.

_contact-sheet.png   Visual index of all 13 with names.

THE 13 STICKERS
---------------
auto-rickshaw · mango · strawberry · lemon · dumbbells · skateboard ·
sneaker · better-soda-phone · juice-glass · movie-ticket ·
lounging-person · headphones · un-stamp

PLACEMENT GUIDANCE (brand)
--------------------------
- Scatter in margins/corners only. Keep the center as open negative space.
- Tilt at playful angles (roughly -14 to +16 deg). Don't lay flat in a grid.
- Soft drop shadow in CSS so they lift off the page:
    filter: drop-shadow(4px 9px 9px rgba(38,66,43,.28));
- Optional: gentle bob/float animation + slight straighten on hover.
- Background stays warm + flat (Cream #FFEDBB / Warm Beige #E0B281).

RESOLUTION
----------
Derived from the original brand sticker sheet (low res). Crisp at the
sizes used on the landing page (~60-220px wide). For large hero or print
use, request VECTOR (.svg / .ai) versions from Confetti
(rishabh@confetti.design). Don't scale these raster files past ~250px wide.

BRAND COLORS
------------
Deep Green #26422B   Burnt Orange #BD6537   Warm Beige #E0B281
Cream #FFEDBB        Soft Blue #D2E8FF

— Bundle prepared for the Uncanned.in web build.
